import express from "express";
import PrestamoRouter from "./src/controllers/prestamoController.js";
import CategoriaRouter from "./src/controllers/categoriaController.js";
import ObjetoRouter from "./src/controllers/objetoController.js";
import cors from 'cors'; // Importa el módulo 'cors' para configurar CORS

const app = express();
const port = 3000;

app.use(express.json());

// Configura CORS para permitir solicitudes desde todos los orígenes
app.use(cors());

app.use("/prestamo", PrestamoRouter);
app.use("/categoria", CategoriaRouter);
app.use("/objeto", ObjetoRouter);

app.listen(port, () => {
    console.log(`Listening on port ${port}`);
});