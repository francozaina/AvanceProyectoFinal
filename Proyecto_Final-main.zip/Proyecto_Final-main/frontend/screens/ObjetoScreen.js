import React from "react";
import Layout from "../components/Layout";
import { View, Text } from "react-native";
import ObjetosComponent from "../components/Objetos";

const ObjetoScreen = () => {
  return (
    <Layout>
      <Text>ObjetoScreen</Text>
    </Layout>
  );
};

export default ObjetoScreen;